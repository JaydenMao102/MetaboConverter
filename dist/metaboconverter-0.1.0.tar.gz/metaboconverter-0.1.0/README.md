# MetaboConverter
# Excel Sheet Viewer

A Python package that allows users to view and analyze Excel sheets through a GUI.

## Installation
## Usage

```python
import excel_sheet_viewer as pk
pk.runApp()
